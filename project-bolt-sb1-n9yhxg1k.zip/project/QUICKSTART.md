# Quick Start Guide

Get your Social Scheduler running in under 10 minutes!

## Step 1: Environment Setup (2 minutes)

```bash
# Copy environment template
cp .env.local.example .env.local

# Generate encryption key (must be 32 characters)
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"

# Generate cron secret
openssl rand -base64 32
```

Edit `.env.local` with:
- Your Supabase URL and anon key (from Supabase dashboard > Settings > API)
- The generated encryption key
- The generated cron secret

## Step 2: Local Test (1 minute)

```bash
npm install
npm run dev
```

Visit `http://localhost:3000` and create a test post.

## Step 3: Deploy to Vercel (3 minutes)

```bash
# Push to GitHub
git init
git add .
git commit -m "Initial commit"
git push
```

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repo
3. Add environment variables (same as `.env.local`)
4. Deploy!

## Step 4: Set Up Cron (3 minutes)

1. Go to [cron-job.org](https://cron-job.org) and sign up
2. Create new cron job:
   - URL: `https://your-app.vercel.app/api/cron/process-queue`
   - Schedule: `*/15 * * * *` (every 15 minutes)
   - Add header: `Authorization: Bearer YOUR_CRON_SECRET`
3. Enable the cron job

## Test It!

1. Create a post scheduled for 2 minutes from now
2. Wait for the cron job to run
3. Refresh - status should change to "PUBLISHED"

Done! Your scheduler is live and fully automated.

## What's Next?

- Read [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for detailed instructions
- Read [README.md](./README.md) for full documentation
- Add Twitter OAuth to actually publish posts

## Common Issues

**Build fails:** Make sure all environment variables are set in Vercel

**Posts not publishing:** Check cron-job.org execution logs and verify the Authorization header is correct

**Supabase errors:** Verify your Supabase project is active and credentials are correct

---

Need help? Check the troubleshooting section in DEPLOYMENT_GUIDE.md
