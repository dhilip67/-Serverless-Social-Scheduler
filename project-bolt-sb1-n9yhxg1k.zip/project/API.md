# API Documentation

## Cron Queue Processor Endpoint

**Endpoint:** `/api/cron/process-queue`

**Method:** `GET`

**Purpose:** Processes queued social media posts and publishes those that are due.

### Authentication

This endpoint requires Bearer token authentication to prevent unauthorized access.

**Header:**
```
Authorization: Bearer YOUR_CRON_SECRET
```

The `CRON_SECRET` must match the value in your environment variables.

### Request

**Example using cURL:**

```bash
curl -X GET https://your-app.vercel.app/api/cron/process-queue \
  -H "Authorization: Bearer your_secret_here"
```

**Example using JavaScript:**

```javascript
const response = await fetch('https://your-app.vercel.app/api/cron/process-queue', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer your_secret_here'
  }
});

const data = await response.json();
console.log(data);
```

### Response

#### Success Response (No Posts Due)

**Status Code:** `200 OK`

```json
{
  "message": "No posts due",
  "processed": 0
}
```

#### Success Response (Posts Processed)

**Status Code:** `200 OK`

```json
{
  "processed": 2,
  "details": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "status": "Success"
    },
    {
      "id": "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
      "status": "Failed",
      "error": "No social account found"
    }
  ]
}
```

#### Unauthorized Response

**Status Code:** `401 Unauthorized`

```json
{
  "error": "Unauthorized"
}
```

This occurs when:
- The Authorization header is missing
- The Authorization header is malformed
- The token doesn't match the CRON_SECRET

#### Error Response

**Status Code:** `500 Internal Server Error`

```json
{
  "error": "Error message here"
}
```

### How It Works

1. **Authentication Check**
   - Verifies the Authorization header matches CRON_SECRET
   - Returns 401 if unauthorized

2. **Query Database**
   - Fetches all posts with:
     - Status: `QUEUED`
     - `scheduled_at` <= current time
   - If no posts found, returns success with processed: 0

3. **Process Each Post**
   - Retrieves the user's social account for the platform
   - Decrypts the access token
   - Attempts to publish the post
   - Updates status to `PUBLISHED` or `FAILED`

4. **Return Results**
   - Returns count of processed posts
   - Returns details of each post's outcome

### Post Status Flow

```
QUEUED → (cron runs) → PUBLISHED ✓
                    → FAILED ✗
```

**QUEUED:** Post is waiting to be published
**PUBLISHED:** Post was successfully published
**FAILED:** Post publication failed (e.g., no account linked, API error)

### Database Queries

The endpoint performs these operations:

1. **Fetch Due Posts:**
   ```sql
   SELECT * FROM posts
   WHERE status = 'QUEUED'
   AND scheduled_at <= NOW()
   ```

2. **Get Social Account:**
   ```sql
   SELECT * FROM social_accounts
   WHERE user_id = ?
   AND provider = ?
   ```

3. **Update Post Status:**
   ```sql
   UPDATE posts
   SET status = 'PUBLISHED' -- or 'FAILED'
   WHERE id = ?
   ```

### Security Features

1. **Token Encryption**
   - Social media access tokens are encrypted at rest
   - Decrypted only when needed for publishing
   - Uses AES-256-CTR encryption

2. **Endpoint Protection**
   - Bearer token authentication required
   - Secret key stored in environment variables
   - Prevents unauthorized post publishing

3. **Row Level Security**
   - Database enforces user isolation
   - Users can only access their own data
   - Supabase RLS policies active on all tables

### Rate Limiting Considerations

**Vercel Free Tier:**
- 100GB-hrs of serverless function execution/month
- Each execution takes ~1-3 seconds
- Safe to run every 15 minutes

**Supabase Free Tier:**
- 50,000 monthly active users
- 2GB bandwidth
- 500MB database storage

### Monitoring

**Check Execution Logs:**

1. **Vercel:**
   - Dashboard > Your Project > Functions
   - View logs for `/api/cron/process-queue`

2. **Cron-job.org:**
   - Dashboard > Your Cron Job
   - View execution history and response codes

**Recommended Alerts:**
- Alert on 401 errors (authentication failure)
- Alert on 500 errors (server errors)
- Alert on execution time > 5 seconds

### Testing

**Test with Manual Trigger:**

```bash
# Create a test post scheduled for now
# Then manually trigger the endpoint

curl -X GET http://localhost:3000/api/cron/process-queue \
  -H "Authorization: Bearer your_local_secret"
```

**Expected Behavior:**
- Post status changes from QUEUED to PUBLISHED
- Response includes post ID in results
- Console logs show "Publishing to..." message

### Extending the Endpoint

To add actual social media publishing:

```typescript
// Inside the post processing loop, replace:
console.log(`Publishing to ${post.platform}: ${post.content}`);

// With actual API calls:
if (post.platform === 'twitter') {
  const client = new TwitterApi(token);
  await client.v2.tweet({ text: post.content });
}

if (post.platform === 'linkedin') {
  // LinkedIn API call
}

if (post.platform === 'facebook') {
  // Facebook API call
}
```

### Error Handling

The endpoint handles these error scenarios:

1. **No Social Account Found**
   - Marks post as FAILED
   - Returns error: "No social account found"

2. **Decryption Failure**
   - Marks post as FAILED
   - Returns error from encryption library

3. **API Failure**
   - Catches exceptions during publish
   - Marks post as FAILED
   - Returns error message

### Best Practices

1. **Keep CRON_SECRET Secure**
   - Don't commit to Git
   - Use strong random values
   - Rotate periodically

2. **Monitor Execution**
   - Set up alerts for failures
   - Review logs weekly
   - Check cron-job.org status

3. **Optimize Frequency**
   - Start with 15-minute intervals
   - Adjust based on usage patterns
   - Consider user timezone distribution

4. **Handle Failures Gracefully**
   - Log detailed error messages
   - Don't retry automatically (to avoid duplicates)
   - Allow users to manually retry failed posts

---

For more information, see the main README.md or DEPLOYMENT_GUIDE.md
