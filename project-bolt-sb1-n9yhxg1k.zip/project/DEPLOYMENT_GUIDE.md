# Deployment Guide - Serverless Social Scheduler

This guide walks you through deploying your Social Scheduler app entirely on free tiers.

## Prerequisites

- GitHub account
- Vercel account (sign up at [vercel.com](https://vercel.com))
- Supabase account (already set up)
- Cron-job.org account (for automation)

## Phase 1: Configure Your Environment

### 1. Generate Required Secrets

Open your terminal and generate the necessary secrets:

```bash
# Generate a 32-character encryption key
node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"

# Generate a secure cron secret
openssl rand -base64 32
```

Save these values - you'll need them in the next steps.

### 2. Set Up Local Development

1. Copy the example environment file:
   ```bash
   cp .env.local.example .env.local
   ```

2. Edit `.env.local` and fill in your values:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
   ENCRYPTION_KEY=your_32_character_key_here
   CRON_SECRET=your_secure_random_string_here
   ```

3. Get your Supabase credentials:
   - Go to your Supabase project dashboard
   - Click "Settings" in the sidebar
   - Click "API"
   - Copy the "Project URL" and "anon public" key

### 3. Test Locally

```bash
npm run dev
```

Visit `http://localhost:3000` and verify:
- The dashboard loads correctly
- You can create a scheduled post
- The post appears in the "Scheduled Posts" section

## Phase 2: Deploy to Vercel

### 1. Push to GitHub

If you haven't already:

```bash
git init
git add .
git commit -m "Initial commit - Social Scheduler"
git branch -M main
git remote add origin https://github.com/yourusername/social-scheduler.git
git push -u origin main
```

### 2. Connect to Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Click "Import Project"
3. Select your GitHub repository
4. Click "Import"

### 3. Configure Environment Variables in Vercel

Before deploying, add your environment variables:

1. In the Vercel import screen, expand "Environment Variables"
2. Add each variable:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `ENCRYPTION_KEY`
   - `CRON_SECRET`

**Important:** Copy the exact values from your `.env.local` file.

### 4. Deploy

1. Click "Deploy"
2. Wait for the deployment to complete (usually 2-3 minutes)
3. You'll get a URL like `https://social-scheduler-xyz.vercel.app`
4. Visit your URL to verify the deployment works

## Phase 3: Set Up the Automation (Cron Job)

This is what makes posts actually publish on schedule!

### 1. Create Cron-job.org Account

1. Go to [cron-job.org](https://cron-job.org)
2. Sign up for a free account
3. Verify your email

### 2. Create the Cron Job

1. After logging in, click "Create cronjob"
2. Fill in the details:

   **Title:** `Social Scheduler Publisher`

   **Address (URL):** `https://your-vercel-url.vercel.app/api/cron/process-queue`

   **Schedule:**
   - Minute: `*/15` (every 15 minutes)
   - Hour: `*` (every hour)
   - Day: `*` (every day)
   - Month: `*` (every month)
   - Weekday: `*` (every day of week)

   **Request method:** `GET`

3. Click "Extended" tab

4. Add Custom Headers:
   - Click "Add header"
   - Name: `Authorization`
   - Value: `Bearer your_cron_secret_here`

   Replace `your_cron_secret_here` with the CRON_SECRET value from your environment variables.

5. Under "Alerts", configure:
   - "On failure" (optional - get email if the cron fails)

6. Click "Create cronjob"

### 3. Test the Cron Job

1. In your app, create a post scheduled for 2 minutes in the future
2. Wait for the next cron execution (check your cron-job.org dashboard)
3. Refresh your app - the post status should change to "PUBLISHED"

## Phase 4: Verification Checklist

Go through this checklist to ensure everything is working:

- [ ] App is deployed and accessible via Vercel URL
- [ ] Can create new scheduled posts
- [ ] Posts appear in the "Scheduled Posts" list
- [ ] Cron job is running every 15 minutes
- [ ] Test post changed from "QUEUED" to "PUBLISHED" after cron execution
- [ ] Can delete posts
- [ ] No errors in Vercel deployment logs

## Manual Cron Test

You can manually trigger the cron job to test it:

```bash
curl -X GET https://your-vercel-url.vercel.app/api/cron/process-queue \
  -H "Authorization: Bearer your_cron_secret"
```

You should see a JSON response like:
```json
{
  "processed": 1,
  "details": [
    {
      "id": "post-id",
      "status": "Success"
    }
  ]
}
```

## Troubleshooting

### Posts Not Publishing

1. Check your cron-job.org execution log:
   - Does it show "Success" or an error?
   - Is the response code 200?

2. Check Vercel function logs:
   - Go to your Vercel project
   - Click "Functions"
   - Check `/api/cron/process-queue` logs

3. Verify the Authorization header is correct:
   - The header must be: `Authorization: Bearer your_secret`
   - Note the space after "Bearer"

### Supabase Connection Errors

1. Verify your environment variables in Vercel:
   - Go to Settings > Environment Variables
   - Make sure URLs don't have trailing slashes

2. Check Supabase project status:
   - Is your project active?
   - Are there any service disruptions?

### Build Failures

If your Vercel build fails:

1. Check the build logs in Vercel
2. Make sure all dependencies are in `package.json`
3. Try building locally: `npm run build`

## Monitoring & Maintenance

### Check Cron Job Health

Visit your cron-job.org dashboard regularly to:
- View execution history
- Check for failures
- See response times

### Monitor Vercel Usage

Free tier limits:
- 100GB bandwidth/month
- 100GB-hrs serverless function execution

Check usage:
- Go to your Vercel dashboard
- Click on your project
- View "Analytics" tab

### Monitor Supabase Usage

Free tier limits:
- 500MB database storage
- 2GB bandwidth

Check usage:
- Go to your Supabase dashboard
- Click "Settings" > "Billing"

## Next Steps

Now that your app is live, consider:

1. **Add OAuth Integration**: Connect real Twitter/LinkedIn accounts
2. **Set Up Custom Domain**: Add a custom domain in Vercel settings
3. **Enable Analytics**: Track post performance
4. **Add User Authentication**: Use Supabase Auth for multi-user support
5. **Upgrade Cron Frequency**: Upgrade to check every 5 or 1 minute

## Free Tier Limits Summary

| Service | Free Tier Limit | Upgrade Cost |
|---------|----------------|--------------|
| Vercel | 100GB bandwidth | $20/month |
| Supabase | 500MB database | $25/month |
| Cron-job.org | 15-min minimum | $3.99/month for 1-min |

---

**Congratulations!** You now have a fully functional, serverless social media scheduler running entirely on free tiers.

For support, open an issue on GitHub or check the main README.md file.
