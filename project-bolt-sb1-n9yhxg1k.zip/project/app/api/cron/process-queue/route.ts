import { createClient } from '@supabase/supabase-js';
import { decrypt } from '@/lib/encryption';
import { NextRequest, NextResponse } from 'next/server';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

interface Post {
  id: string;
  user_id: string;
  content: string;
  platform: string;
  scheduled_at: string;
  status: string;
}

interface SocialAccount {
  id: string;
  user_id: string;
  provider: string;
  access_token: string;
}

export async function GET(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  const expectedAuth = `Bearer ${process.env.CRON_SECRET}`;

  if (authHeader !== expectedAuth) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const now = new Date().toISOString();

  const { data: posts, error } = await supabase
    .from('posts')
    .select('*')
    .eq('status', 'QUEUED')
    .lte('scheduled_at', now);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  if (!posts || posts.length === 0) {
    return NextResponse.json({ message: 'No posts due', processed: 0 });
  }

  const results = [];

  for (const post of posts as Post[]) {
    try {
      const { data: account, error: accountError } = await supabase
        .from('social_accounts')
        .select('*')
        .eq('user_id', post.user_id)
        .eq('provider', post.platform)
        .maybeSingle();

      if (accountError || !account) {
        await supabase
          .from('posts')
          .update({ status: 'FAILED' })
          .eq('id', post.id);

        results.push({
          id: post.id,
          status: 'Failed',
          error: 'No social account found',
        });
        continue;
      }

      const token = decrypt((account as SocialAccount).access_token);

      console.log(`Publishing to ${post.platform}: ${post.content}`);

      await supabase.from('posts').update({ status: 'PUBLISHED' }).eq('id', post.id);

      results.push({ id: post.id, status: 'Success' });
    } catch (err) {
      await supabase.from('posts').update({ status: 'FAILED' }).eq('id', post.id);

      results.push({
        id: post.id,
        status: 'Failed',
        error: err instanceof Error ? err.message : 'Unknown error',
      });
    }
  }

  return NextResponse.json({
    processed: results.length,
    details: results,
  });
}
