'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Calendar, Clock, Send, Trash2, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';

interface Post {
  id: string;
  content: string;
  platform: string;
  scheduled_at: string;
  status: string;
  created_at: string;
}

export default function Dashboard() {
  const [content, setContent] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [platform, setPlatform] = useState('twitter');
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    initializeUser();
    fetchPosts();
  }, []);

  const initializeUser = async () => {
    const tempUserId = 'demo-user-' + Math.random().toString(36).substring(7);
    setUserId(tempUserId);

    const { error } = await supabase
      .from('users')
      .upsert({ id: tempUserId, email: `${tempUserId}@demo.com` }, { onConflict: 'id' });

    if (error) console.error('User initialization error:', error);
  };

  const fetchPosts = async () => {
    const { data, error } = await supabase
      .from('posts')
      .select('*')
      .order('scheduled_at', { ascending: true });

    if (!error && data) {
      setPosts(data);
    }
  };

  const handleSchedule = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!content || !scheduledDate || !scheduledTime || !userId) {
      alert('Please fill in all fields');
      return;
    }

    setLoading(true);

    const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);

    if (scheduledDateTime < new Date()) {
      alert('Please select a future date and time');
      setLoading(false);
      return;
    }

    const { error } = await supabase.from('posts').insert({
      user_id: userId,
      content: content,
      platform: platform,
      scheduled_at: scheduledDateTime.toISOString(),
      status: 'QUEUED',
    });

    if (error) {
      alert('Error scheduling post: ' + error.message);
    } else {
      setContent('');
      setScheduledDate('');
      setScheduledTime('');
      fetchPosts();
    }

    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('posts').delete().eq('id', id);

    if (!error) {
      fetchPosts();
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PUBLISHED':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'FAILED':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'QUEUED':
        return <Clock className="w-5 h-5 text-blue-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      PUBLISHED: 'bg-green-100 text-green-800 border-green-200',
      FAILED: 'bg-red-100 text-red-800 border-red-200',
      QUEUED: 'bg-blue-100 text-blue-800 border-blue-200',
    };

    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${styles[status as keyof typeof styles] || 'bg-gray-100 text-gray-800'}`}>
        {status}
      </span>
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-6xl mx-auto p-6 lg:p-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Social Scheduler</h1>
          <p className="text-slate-600">Schedule your social media posts with ease</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h2 className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <Send className="w-5 h-5 text-blue-600" />
              Create New Post
            </h2>

            <form onSubmit={handleSchedule} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Platform
                </label>
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white text-slate-900"
                >
                  <option value="twitter">Twitter</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="facebook">Facebook</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Post Content
                </label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="What's on your mind?"
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none text-slate-900"
                  rows={4}
                  maxLength={280}
                  required
                />
                <p className="text-xs text-slate-500 mt-1">{content.length}/280 characters</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Date
                  </label>
                  <input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2 flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    Time
                  </label>
                  <input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-slate-900"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Scheduling...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Schedule Post
                  </>
                )}
              </button>
            </form>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl shadow-sm p-6 text-white">
            <h2 className="text-xl font-semibold mb-4">How It Works</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-white/20 rounded-lg p-2 mt-1">
                  <span className="text-lg font-bold">1</span>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Create Your Post</h3>
                  <p className="text-blue-100 text-sm">Write your content and choose the platform</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-white/20 rounded-lg p-2 mt-1">
                  <span className="text-lg font-bold">2</span>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Schedule the Time</h3>
                  <p className="text-blue-100 text-sm">Pick when you want it to go live</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-white/20 rounded-lg p-2 mt-1">
                  <span className="text-lg font-bold">3</span>
                </div>
                <div>
                  <h3 className="font-medium mb-1">Sit Back & Relax</h3>
                  <p className="text-blue-100 text-sm">Your post will be published automatically</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Scheduled Posts</h2>

          {posts.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500">No posts scheduled yet</p>
              <p className="text-sm text-slate-400 mt-1">Create your first post to get started</p>
            </div>
          ) : (
            <div className="space-y-3">
              {posts.map((post) => (
                <div
                  key={post.id}
                  className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        {getStatusIcon(post.status)}
                        <span className="text-xs font-medium text-slate-500 uppercase">
                          {post.platform}
                        </span>
                        {getStatusBadge(post.status)}
                      </div>
                      <p className="text-slate-900 mb-2 line-clamp-2">{post.content}</p>
                      <div className="flex items-center gap-4 text-sm text-slate-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {formatDate(post.scheduled_at)}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(post.id)}
                      className="text-slate-400 hover:text-red-600 transition-colors p-2 hover:bg-red-50 rounded-lg"
                      title="Delete post"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Note:</strong> This is a demo version. To actually publish posts, you'll need to connect your social media accounts and set up the cron job as described in the deployment guide.
          </p>
        </div>
      </div>
    </div>
  );
}
