# Serverless Social Scheduler

A fully serverless social media scheduling platform built with Next.js, Supabase, and automated cron jobs. Schedule posts to Twitter, LinkedIn, and Facebook without any servers running 24/7.

## Features

- **Schedule Posts**: Create and schedule social media posts for future publication
- **Multi-Platform Support**: Twitter, LinkedIn, and Facebook ready
- **Encrypted Tokens**: Social media access tokens are encrypted before storage
- **Serverless Architecture**: No servers to maintain, runs entirely on free tier
- **Beautiful Dashboard**: Clean, modern UI for managing your scheduled posts
- **Status Tracking**: Monitor post status (Queued, Published, Failed)

## Tech Stack

- **Frontend**: Next.js 13+ (App Router), React, TypeScript, Tailwind CSS
- **Database**: Supabase (PostgreSQL with Row Level Security)
- **Authentication**: Supabase Auth (ready for OAuth integration)
- **Deployment**: Vercel (Free Tier)
- **Automation**: Cron-job.org (Free Tier)

## Getting Started

### 1. Clone & Install

```bash
git clone <your-repo-url>
cd social-scheduler
npm install
```

### 2. Set Up Supabase

1. Go to [supabase.com](https://supabase.com) and create a free account
2. Create a new project
3. The database schema has already been created via migration
4. Get your project URL and anon key from Settings > API

### 3. Configure Environment Variables

1. Copy `.env.local.example` to `.env.local`
2. Fill in your Supabase credentials:
   - `NEXT_PUBLIC_SUPABASE_URL`: Your Supabase project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase anon/public key

3. Generate an encryption key (must be exactly 32 characters):
   ```bash
   node -e "console.log(require('crypto').randomBytes(16).toString('hex'))"
   ```

4. Create a secure cron secret (any random string):
   ```bash
   openssl rand -base64 32
   ```

### 4. Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) to see the dashboard.

## Deployment

### Deploy to Vercel

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) and import your repository
3. Add all environment variables from `.env.local` in the Vercel dashboard
4. Deploy!

### Set Up Cron Job (The Magic Part)

This is what makes the posts actually publish on schedule:

1. Go to [cron-job.org](https://cron-job.org) and create a free account
2. Create a new cron job:
   - **Title**: Social Scheduler Publisher
   - **URL**: `https://your-vercel-url.vercel.app/api/cron/process-queue`
   - **Schedule**: Every 15 minutes (or your preferred interval)
   - **Request Method**: GET
   - **Headers**: Add a custom header:
     - **Name**: `Authorization`
     - **Value**: `Bearer your_cron_secret_here`

3. Save and enable the cron job

Now your posts will be automatically checked and published every 15 minutes!

## How It Works

### Architecture

```
User creates post → Saved to Supabase → Cron job triggers every 15 min
                                                      ↓
                                         Checks for due posts
                                                      ↓
                                         Publishes to social media
                                                      ↓
                                         Updates status in database
```

### Database Schema

- **users**: User accounts
- **social_accounts**: Encrypted OAuth tokens for social media platforms
- **posts**: Scheduled posts queue with status tracking

### Security Features

- Row Level Security (RLS) enabled on all tables
- Access tokens encrypted with AES-256-CTR
- Cron endpoint protected with bearer token
- User data isolation (users can only access their own data)

## Adding Social Media Integration

Currently, the app is set up as a demo. To actually publish posts, you need to:

### Twitter/X Integration

1. Create a Twitter Developer Account at [developer.twitter.com](https://developer.twitter.com)
2. Create a new app and get OAuth 2.0 credentials
3. Implement OAuth flow to get user access tokens
4. Store encrypted tokens in `social_accounts` table
5. Update the cron endpoint to use Twitter API:
   ```typescript
   import { TwitterApi } from 'twitter-api-v2';

   const client = new TwitterApi(decryptedToken);
   await client.v2.tweet(post.content);
   ```

### LinkedIn Integration

Similar process using LinkedIn's OAuth and API.

## Testing the Queue Processor

You can manually trigger the queue processor:

```bash
curl -X GET https://your-vercel-url.vercel.app/api/cron/process-queue \
  -H "Authorization: Bearer your_cron_secret"
```

## Free Tier Limits

This entire setup runs on free tiers:

- **Supabase**: 500MB database, 50,000 monthly active users
- **Vercel**: 100GB bandwidth, unlimited requests
- **Cron-job.org**: 1-minute interval minimum, unlimited jobs

Perfect for personal use or small projects!

## Project Structure

```
social-scheduler/
├── app/
│   ├── api/
│   │   └── cron/
│   │       └── process-queue/
│   │           └── route.ts          # Queue processor endpoint
│   ├── layout.tsx
│   └── page.tsx                      # Main dashboard
├── lib/
│   ├── encryption.ts                 # Token encryption utilities
│   └── supabase.ts                   # Supabase client
├── components/
│   └── ui/                          # shadcn/ui components
├── .env.local.example               # Environment template
└── README.md
```

## Future Enhancements

- [ ] Full OAuth integration for Twitter, LinkedIn, Facebook
- [ ] Post analytics and performance tracking
- [ ] Content calendar view
- [ ] Post templates
- [ ] Image upload support
- [ ] Multi-account support per platform
- [ ] Timezone selection
- [ ] Post preview before publishing

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - feel free to use this project however you'd like!

## Support

If you run into any issues, please open an issue on GitHub or check the deployment logs in Vercel.

---

Built with Next.js, Supabase, and lots of free tier services.
