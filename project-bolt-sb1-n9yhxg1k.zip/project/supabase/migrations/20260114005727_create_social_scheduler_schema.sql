/*
  # Social Scheduler Database Schema
  
  Creates the complete database structure for the Serverless Social Scheduler application.
  
  ## New Tables
  
  1. `users`
     - `id` (uuid, primary key) - Unique user identifier
     - `email` (text, unique) - User email address
     - `created_at` (timestamptz) - Account creation timestamp
     - Purpose: Stores user account information
  
  2. `social_accounts`
     - `id` (uuid, primary key) - Unique account identifier
     - `user_id` (uuid, foreign key) - Links to users table
     - `provider` (text) - Social media platform name (twitter, linkedin, etc)
     - `access_token` (text) - Encrypted OAuth access token
     - `created_at` (timestamptz) - Connection timestamp
     - Purpose: Stores encrypted social media account credentials
  
  3. `posts`
     - `id` (uuid, primary key) - Unique post identifier
     - `user_id` (uuid, foreign key) - Links to users table
     - `content` (text) - Post content/message
     - `platform` (text) - Target platform (twitter, linkedin, etc)
     - `scheduled_at` (timestamptz) - When to publish the post
     - `status` (text) - Current status (QUEUED, PUBLISHED, FAILED)
     - `created_at` (timestamptz) - Creation timestamp
     - Purpose: Queue of scheduled social media posts
  
  ## Security (RLS Policies)
  
  All tables have Row Level Security enabled with restrictive policies:
  
  ### Users Table
  - Users can only view their own profile data
  - Users can update their own profile data
  
  ### Social Accounts Table
  - Users can only view their own connected accounts
  - Users can create new account connections
  - Users can delete their own account connections
  
  ### Posts Table
  - Users can view only their own posts
  - Users can create new posts
  - Users can update their own posts
  - Users can delete their own posts
  
  ## Important Notes
  
  1. **Data Security**: Access tokens are stored encrypted in the database
  2. **User Isolation**: All RLS policies ensure users can only access their own data
  3. **Cascading Deletes**: When a user is deleted, all their accounts and posts are automatically removed
  4. **Default Values**: Posts default to QUEUED status, all timestamps default to now()
*/

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on users table
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- 2. SOCIAL ACCOUNTS TABLE
CREATE TABLE IF NOT EXISTS social_accounts (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider text NOT NULL,
  access_token text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on social_accounts table
ALTER TABLE social_accounts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for social_accounts table
CREATE POLICY "Users can view own social accounts"
  ON social_accounts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own social accounts"
  ON social_accounts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own social accounts"
  ON social_accounts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 3. POSTS TABLE
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  platform text NOT NULL,
  scheduled_at timestamptz NOT NULL,
  status text DEFAULT 'QUEUED',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on posts table
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- RLS Policies for posts table
CREATE POLICY "Users can view own posts"
  ON posts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own posts"
  ON posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own posts"
  ON posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_social_accounts_user_id ON social_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_social_accounts_provider ON social_accounts(provider);
CREATE INDEX IF NOT EXISTS idx_posts_user_id ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status);
CREATE INDEX IF NOT EXISTS idx_posts_scheduled_at ON posts(scheduled_at);